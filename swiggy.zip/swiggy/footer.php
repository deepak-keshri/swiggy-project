<div class="box-bottom">
  <div id="footer">
    <div id="cantainer">
      <div class="row">
        <div class="footer-col">
          <h4>COMPANY</h4>
          <ul>
            <li><a href="#">About us</a></li><br>
            <li><a href="#">Team</a></li><br>
            <li><a href="#">Careers</a></li><br>
            <li><a href="#">Swiggy Blog</a></li><br>
            <li><a href="#">Bug Bounty</a></li><br>
            <li><a href="#"> Swigggy One</a></li><br>
            <li><a href="#"> Swiggy Corporate</a></li><br>
            <li><a href="#">Swiggy Instamart</a></li><br>
          </ul>
        </div>
        <br>
        <div class="footer-col">
          <h4>CONTACT</h4>
          <ul>
            <li><a href="#">HELP&Support</a></li><br>
            <li><a href="#">Partner with us</a></li><br>
            <li><a href="#">Ride with us</a></li><br>
          </ul>
        </div>
        <br>
        <div class="footer-col">
          <h4>LEGAL</h4>
          <ul>
            <li><a href="#">Terms&condition</a></li><br>
            <li><a href="#">rufound&cancelllation</a></li><br>
            <li><a href="#">Privacy Policy</a></li><br>
            <li><a href="#">Cookie Policy</a></li><br>
            <li><a href="#"> Offer Terms</a></li><br>
            <li><a href="#"> Phishing&Fraud</a></li><br>
        </div>
        <div class="img-div">
          <img src="image\playstore.png"><br>
          <img src="image\apple.png">
        </div>
        </ul>
      </div>
    </div>
  </div>
</div>
<hr>
</body>
</html>
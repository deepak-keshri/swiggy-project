localStorage.removeItem("name");
localStorage.removeItem("image");
localStorage.removeItem("qty");
localStorage.removeItem("price");
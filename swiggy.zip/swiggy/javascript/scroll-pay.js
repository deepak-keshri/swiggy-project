window.addEventListener("scroll", function () {
  let header = document.getElementById("header");

  if (window.pageYOffset >= 0) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
});

var ind = 0;
function Error() {
  alert("Please Choose at least any one products");
}
function CheckEmpty() {
  let c = 0;
  let i = 0;
  for (i = 0; i <= parseInt(localStorage.getItem("total_ind")); i++) {
    if (localStorage.getItem(`qty[${i}]`) == null) {
      c++;
    }
  }

  if (i == c) {
    let f = document.getElementsByClassName("pay-money")[0];
    f.href = "#";
    f.setAttribute("onclick", "Error()");
  } else {
    let f = document.getElementsByClassName("pay-money")[0];
    f.href = "pay.php";
  }
}
function Total() {
  let total = 0;
  let length = parseInt(localStorage.getItem("total_ind"));
  for (let i = 0; i <= length; i++) {
    let q = parseInt(localStorage.getItem(`qty[${i}]`));
    let p = parseInt(localStorage.getItem(`price[${i}]`));

    if (q >= 1) total = total + p * q;
  }
  let gst = parseInt((total * 3) / 100);
  document.getElementById("tax-tax1").innerHTML = gst;
  document.getElementById("to-pay-money").innerHTML = gst + total + 10;
  document.getElementById("total-cost").innerHTML = total;
  CheckEmpty();
}

function ShowAll() {
  let length = parseInt(localStorage.getItem("total_ind"));
  for (let i = 0; i <= length; i++) {
    let p = parseInt(localStorage.getItem(`price[${i}]`));
    let q = parseInt(localStorage.getItem(`qty[${i}]`));
    let n = localStorage.getItem(`name[${i}]`);
    let img = localStorage.getItem(`image[${i}]`);

    if (q >= 0) {
      n = n.toUpperCase();
      let right = document.getElementsByClassName("cart-item1")[0];

      let cart = document.createElement("div");
      cart.setAttribute("class", "cart-item");
      right.appendChild(cart);

      let span = document.createElement("span");
      span.classList.add("descrip");
      let txt = document.createTextNode(n);
      span.appendChild(txt);
      cart.appendChild(span);

      let increase = document.createElement("span");
      increase.classList.add("increase");
      cart.appendChild(increase);

      /*crease - button */
      let dec = document.createElement("input");
      dec.setAttribute("class", "dec");
      dec.setAttribute("type", "button");
      dec.setAttribute("value", "-");
      dec.setAttribute("onClick", `Decrease(${i})`);
      increase.appendChild(dec);

      /* crease input type text area */
      let val1 = document.createElement("input");
      val1.setAttribute("class", "val");
      val1.setAttribute("type", "text");
      val1.setAttribute("value", q);
      val1.setAttribute("readonly", "");
      val1.setAttribute("name", "qty");
      increase.appendChild(val1);

      /* create + button */
      let inc = document.createElement("input");
      inc.setAttribute("class", "inc");
      inc.setAttribute("type", "button");
      inc.setAttribute("value", "+");
      inc.setAttribute("onClick", `Increase(${i})`);
      increase.appendChild(inc);

      let rupees = document.createElement("span");
      rupees.setAttribute("class", "rupees");
      let symbol = document.createTextNode("Rs. ");
      rupees.appendChild(symbol);
      cart.appendChild(rupees);

      let trs1 = document.createElement("b");
      trs1.setAttribute("class", "rs");
      let prs = document.createTextNode(p);
      trs1.appendChild(prs);
      rupees.appendChild(trs1);
    }
    UpdateItselt(i);
  }
  
  Total();
}
ShowAll();

function UpdateItselt(ind) {
  let q = parseInt(localStorage.getItem(`qty[${ind}]`));
  let p = parseInt(localStorage.getItem(`price[${ind}]`));

  document.getElementsByClassName("rs")[ind].innerHTML = q * p;
}

function Increase(index) {
  let q = parseInt(localStorage.getItem(`qty[${index}]`));

  q = q + 1;
  localStorage.setItem(`qty[${index}]`, q);
  document.getElementsByClassName("val")[index].value = q;
  Total();
  UpdateItselt(index);
}

function Decrease(index) {
  let q = parseInt(localStorage.getItem(`qty[${index}]`));
  q = q - 1;
  localStorage.setItem(`qty[${index}]`, q);
  document.getElementsByClassName("val")[index].value = q;

  if (q <= 0) {
    localStorage.removeItem(`name[${index}]`);
    localStorage.removeItem(`price[${index}]`);
    localStorage.removeItem(`qty[${index}]`);
    localStorage.removeItem(`image[${index}]`);
    document
      .getElementsByClassName("cart-item")
      [index].classList.add("hideMeContent");
  } else UpdateItselt(index);

  Total();
}

function CurrentLink() {
  let active = document.getElementsByClassName("active");
  alert("first");
  let act = document.getElementsByClassName("header2-link");
  act[0].classList.add("active-link");
  active[0].classList.remove("active-link");
  active[1].classList.remove("active-link");
  active[2].classList.remove("active-link");
  active[3].classList.remove("active-link");
  // active[4].classList.remove("active-link");
}

function CurrentLink1() {
  alert("second");
  let active = document.getElementsByClassName("active");
  let act = document.getElementsByClassName("header2-link");
  act[0].classList.remove("active-link");
  active[0].classList.add("active-link");
  active[1].classList.remove("active-link");
  active[2].classList.remove("active-link");
  active[3].classList.remove("active-link");
  // active[4].classList.remove("active-link");
}

function CurrentLink2() {
  let active = document.getElementsByClassName("active");
  let act = document.getElementsByClassName("header2-link");
  act[0].classList.remove("active-link");
  active[0].classList.remove("active-link");
  active[1].classList.add("active-link");
  active[2].classList.remove("active-link");
  active[3].classList.remove("active-link");
  // active[4].classList.remove("active-link");
}

function CurrentLink3() {
  let active = document.getElementsByClassName("active");
  let act = document.getElementsByClassName("header2-link");
  act[0].classList.remove("active-link");
  active[0].classList.remove("active-link");
  active[1].classList.remove("active-link");
  active[2].classList.add("active-link");
  active[3].classList.remove("active-link");
  // active[4].classList.remove("active-link");
}

function CurrentLink4() {
  let active = document.getElementsByClassName("active");
  let act = document.getElementsByClassName("header2-link");
  act[0].classList.remove("active-link");
  active[0].classList.remove("active-link");
  active[1].classList.remove("active-link");
  active[2].classList.remove("active-link");
  active[3].classList.add("active-link");
  // active[4].classList.remove("active-link");
}

/* Below all function used in filter link */
/* It check any one option is checked or not */
function enableMe() {
  document.getElementsByClassName("btn2")[0].disabled = false;
}
function ClearAll() {
  let checkme = document.getElementsByClassName("checkme");
  document.getElementsByClassName("btn2")[0].disabled = false;
  for (let i = 0; i < checkme.length; i++) {
    if (checkme[i].checked == true) {
      checkme[i].checked = false;
    }
  }
}
function isChecked() {
  let checkme = document.getElementsByClassName("checkme");
  let f = 0;
  for (let i = 0; i < checkme.length; i++) {
    if (checkme[i].checked == true) {
      f = 1;
      break;
    }
  }
  if (f == 1) document.getElementsByClassName("btn2")[0].disabled = false;
  else {
    document.getElementsByClassName("btn2")[0].disabled = true;
    alert("Please Check at least One");
  }
}

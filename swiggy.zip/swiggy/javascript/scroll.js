window.addEventListener("scroll", function () {
  let header = document.getElementById("header");
  let header1 = document.getElementById("header2");

  if (window.pageYOffset >= 0) {
    header.classList.add("sticky");
    //console.log("hello");
  } else {
    header.classList.remove("sticky");
  }
  if (window.pageYOffset >= 430) {
    header.classList.remove("sticky");
    header1.classList.add("sticky1");
  } else {
    header1.classList.remove("sticky1");
  }
}); 
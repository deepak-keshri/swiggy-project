function Pay() {
  let name = localStorage.getItem("name");
  let qty = localStorage.getItem("qty");
  let price = localStorage.getItem("price");
  let image = localStorage.getItem("image");
  let img = "image/"+image;
  //alert(img);
  //alert(image);
  //document.getElementById("setProduct").scr = ("image/"+image);
  //document.getElementById("setProduct").src = img;
  document.getElementById("setItemName").innerHTML = name;
  document.getElementById("header-part-child").innerHTML = name;
  document.getElementsByClassName("val")[0].value = qty;
  document.getElementById("product-price").innerHTML = "Rs. " + price * qty;
  document.getElementById("money").innerHTML = "Rs. " + price * qty;
  document.getElementById("tax").innerHTML = "Rs. " + (price * qty*3)/100;
  document.getElementById("to-pay-money").innerHTML = Math.floor((price*qty)+(price*qty*3)/100+10);
}
//Pay();

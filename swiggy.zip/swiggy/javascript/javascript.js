function CurrentLink(obj)
{
  //alert(obj);
  console.log("black");
  // obj.style.bottomBorder="1px solid black";
  obj.style.color="red";
}

function OpenLogin()
{
  let main3 = document.getElementsByClassName("main-box3")[0];
  let main = document.getElementsByClassName("main-box")[0];
  // let container = document.getElementsByClassName("main-container")[0];
  
  main.classList.add("showData");
  main3.classList.remove("showData");
  document.getElementById("dk").style.overflowY="hidden";
}

function CloseLogin(){
  let main = document.getElementsByClassName("main-box")[0];
  main.classList.remove("showData");
  document.getElementById("dk").style.overflowY="visible";
  
}

function ShowSignup()
{
  let main = document.getElementsByClassName("main-box")[0];
  let main3 = document.getElementsByClassName("main-box3")[0];
  
  main.classList.remove("showData");
  main3.classList.add("showData");
  document.getElementById("dk").style.overflowY="hidden";
}

function CloseSignup()
{
  let main3 = document.getElementsByClassName("main-box3")[0];
  main3.classList.remove("showData");
  document.getElementById("dk").style.overflowY="visible";
}

/* Used in filter1 class in home.php and header2.php */
function ShowFilter(){
  let filter = document.getElementsByClassName("filter1")[0];
  filter.classList.add("showData"); 
  document.getElementById("dk").style.overflowY="hidden";
}

function HideFilter(){
  let filter = document.getElementsByClassName("filter1")[0];
  filter.classList.remove("showData"); 
  document.getElementById("dk").style.overflowY="visible";
}

/* Used in Search box */
function ShowSearchBox()
{
  let search = document.getElementsByClassName("main-div")[0];
  search.classList.add("showData");
  document.getElementById("dk").style.overflowY="hidden";
}
function HideSearchBox()
{
  let search = document.getElementsByClassName("main-div")[0];
  search.classList.remove("showData");
  document.getElementById("dk").style.overflowY="visible";
  // alert("hellow");
}

/* Hide and Show Location */
function ShowLocation()
{
  let location = document.getElementsByClassName("location")[0];
  location.classList.add("showData");

  document.getElementById("dk").style.overflowY="hidden";
}
function HideLocation()
{
  let location = document.getElementsByClassName("location")[0];
  location.classList.remove("showData");
  
  document.getElementById("dk").style.overflowY="visible";
}

/* Used in header bottom */
var x=0;
function nextImage()
{
  console.log("nextImage")
  let nextImg = document.getElementsByClassName("nextImg");
  
  for(let i = 0; i <= nextImg.length; i++){
    
    if (i>=x && i<=(x+3))
    nextImg[i].style.display="inline-block";
    else
    nextImg[i].style.display="none";    
  }
  x++;
  if (x==3)
  x=0;
}
//


/* Used in on scroll page */
window.addEventListener("scroll", function () {
  let view = document.getElementsByClassName("view-part");
  let view1 = document.getElementsByClassName("view-part1")[0];
  let img = document.getElementsByClassName("offer-img")[0];

  let hidepart = document.getElementsByClassName("p-country")[0];
  let hidepart1 = document.getElementsByClassName("p-address")[0];
  let hidepart2 = document.getElementsByClassName("p-time-tr")[0];

  let filter = document.getElementsByClassName("filter")[0];

  let leftdata = document.getElementsByClassName("left-data")[0];
  let rightdata = document.getElementsByClassName("right-data")[0];
  let middledata = document.getElementsByClassName("middle-data")[0];

  let data = document.getElementsByClassName("data")[0];
  if (window.pageYOffset >= 93) {
    view[0].classList.add("sticky3");
    view1.classList.add("sticky4");
    img.classList.add("sticky5");
    hidepart.classList.add("hideme");
    hidepart1.classList.add("hideme");
    hidepart2.classList.add("hideme");
    filter.classList.add("filter-manage");
    data.classList.add("sticky6");
  } else {
    view[0].classList.remove("sticky3");
    view1.classList.remove("sticky4");
    img.classList.remove("sticky5");
    hidepart.classList.remove("hideme");
    hidepart1.classList.remove("hideme");
    hidepart2.classList.remove("hideme");
    filter.classList.remove("filter-manage");
    data.classList.remove("sticky6");
  }

  if (window.pageYOffset >= 145) {
    leftdata.classList.add("data-fixed-left");
    rightdata.classList.add("data-fixed-right");
    middledata.classList.add("data-fixed-middle");
  } else {
    leftdata.classList.remove("data-fixed-left");
    rightdata.classList.remove("data-fixed-right");
    middledata.classList.remove("data-fixed-middle");
  }
});


var qty = 1;
function AddItem(name,id,price)
{
  //alert(id+" "+name+" "+price);
  let rightdata = document.getElementsByClassName('right-data1')[0];
  let descrip = document.getElementsByClassName('descrip')[0];
  let rs = document.getElementsByClassName('rs')[0];
  let trs = document.getElementsByClassName('trs')[0];
  let val = document.getElementsByClassName('val')[0];

  rightdata.classList.add("right-data-show");
  if (name!="" && id!="" && price!="")
  {
    localStorage.setItem("name",name);
    localStorage.setItem("price",price);
  }
  descrip.innerHTML = localStorage.getItem("name");
  rs.innerHTML = localStorage.getItem("price");
  trs.innerHTML = qty*localStorage.getItem("price");
  val.value = qty;
  // trs.innerHTML = qty*price;
}

function Increase()
{
  qty++;
  AddItem("","","");
}

function Decrease()
{
  qty--;
  if (qty <= 0)
  {
    let rightdata = document.getElementsByClassName('right-data1')[0];
    rightdata.classList.remove("right-data-show");

    localStorage.removeItem("name");
    localStorage.removeItem("price");
  }
  else
  AddItem("","","");
}



window.addEventListener('scroll',function(){
  let header = document.getElementById("header");
  let header1 = document.getElementById("header2");

  if (window.pageYOffset >= 16)
  {
    header.classList.add("sticky");
    console.log("hello");
  }
  else
  {
    // console.log("hello No");
    header.classList.remove("sticky");
  }

  // console.log("hello No");
  if (window.pageYOffset >= 430)
  {
    header.classList.remove("sticky");
    header1.classList.add("sticky1");
  }
  else
  {
    header1.classList.remove("sticky1");
  }
})


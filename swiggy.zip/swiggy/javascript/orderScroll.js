window.addEventListener("scroll", function () {
  let view = document.getElementsByClassName("view-part");
  let view1 = document.getElementsByClassName("view-part1")[0];
  let img = document.getElementsByClassName("offer-img")[0];

  let hidepart = document.getElementsByClassName("p-country")[0];
  let hidepart1 = document.getElementsByClassName("p-address")[0];
  let hidepart2 = document.getElementsByClassName("p-time-tr")[0];

  let filter = document.getElementsByClassName("filter")[0];

  let leftdata = document.getElementsByClassName("left-data")[0];
  let rightdata = document.getElementsByClassName("right-data")[0];
  let middledata = document.getElementsByClassName("middle-data")[0];

  let data = document.getElementsByClassName("data")[0];
  if (window.pageYOffset >= 93) {
    view[0].classList.add("sticky3");
    view1.classList.add("sticky4");
    img.classList.add("sticky5");
    hidepart.classList.add("hideme");
    hidepart1.classList.add("hideme");
    hidepart2.classList.add("hideme");
    filter.classList.add("filter-manage");
    data.classList.add("sticky6");
  } else {
    view[0].classList.remove("sticky3");
    view1.classList.remove("sticky4");
    img.classList.remove("sticky5");
    hidepart.classList.remove("hideme");
    hidepart1.classList.remove("hideme");
    hidepart2.classList.remove("hideme");
    filter.classList.remove("filter-manage");
    data.classList.remove("sticky6");
  }

  if (window.pageYOffset >= 145) {
    leftdata.classList.add("data-fixed-left");
    rightdata.classList.add("data-fixed-right");
    middledata.classList.add("data-fixed-middle");
  } else {
    leftdata.classList.remove("data-fixed-left");
    rightdata.classList.remove("data-fixed-right");
    middledata.classList.remove("data-fixed-middle");
  }
});

//var qty = 1;
var ind = 0;
function CheckEmpty() {
  let c = 0;
  let i = 0;
  for (i = 0; i <= parseInt(localStorage.getItem("total_ind")); i++) {
    if (localStorage.getItem(`qty[${i}]`) == null) {
      c++;
    }
  }

  if (i == c) {
    document.getElementsByClassName("checkout")[0].disabled = true;
  } else {
    document.getElementsByClassName("checkout")[0].disabled = false;
  }
}
function AddItem(name, id, price, image) {
  let right = document.getElementsByClassName("cart-item1")[0];

  let cart = document.createElement("div");
  cart.setAttribute("class", "cart-item");
  right.appendChild(cart);

  let span = document.createElement("span");
  span.classList.add("descrip");
  let txt = document.createTextNode(name);
  span.appendChild(txt);
  cart.appendChild(span);

  let increase = document.createElement("span");
  increase.classList.add("increase");
  cart.appendChild(increase);

  /*crease - button */
  let dec = document.createElement("input");
  dec.setAttribute("class", "dec");
  dec.setAttribute("type", "button");
  dec.setAttribute("value", "-");
  dec.setAttribute("onClick", `Decrease(${id},${ind})`);
  increase.appendChild(dec);

  /* crease input type text area */
  let val1 = document.createElement("input");
  val1.setAttribute("class", "val");
  val1.setAttribute("type", "text");
  val1.setAttribute("value", "1");
  val1.setAttribute("readonly", "");
  val1.setAttribute("name", "qty");
  increase.appendChild(val1);

  /* create + button */
  let inc = document.createElement("input");
  inc.setAttribute("class", "inc");
  inc.setAttribute("type", "button");
  inc.setAttribute("value", "+");
  inc.setAttribute("onClick", `Increase(${ind})`);
  increase.appendChild(inc);

  let rupees = document.createElement("span");
  rupees.setAttribute("class", "rupees");
  let symbol = document.createTextNode("Rs. ");
  rupees.appendChild(symbol);
  cart.appendChild(rupees);

  let trs1 = document.createElement("b");
  trs1.setAttribute("class", "rs");
  let prs = document.createTextNode(price);
  trs1.appendChild(prs);
  rupees.appendChild(trs1);

  document.getElementById("button-id" + id).disabled = true;

  let rightdata = document.getElementsByClassName("right-data1")[0];

  rightdata.classList.add("right-data-show");

  localStorage.setItem(`name[${ind}]`, name);
  localStorage.setItem(`image[${ind}]`, image);
  localStorage.setItem(`qty[${ind}]`, 1);
  localStorage.setItem(`price[${ind}]`, price);
  localStorage.setItem(`total_ind`, ind);

  DataShow(ind);
  Total();
  ind++;
}
function DataShow(ind) {
  document.getElementById("product_img").value = localStorage.getItem(
    `image[${ind}]`
  );
  document.getElementById("product_qty").value = localStorage.getItem(
    `qty[${ind}]`
  );
  document.getElementById("product_name").value = localStorage.getItem(
    `name[${ind}]`
  );
  document.getElementById("product_price").value = localStorage.getItem(
    `price[${ind}]`
  );
}

function Increase(index) {
  //index--;
  let q = parseInt(localStorage.getItem(`qty[${index}]`));
  //alert(localStorage.getItem(`image[${index}]`));
  q = q + 1;
  localStorage.setItem(`qty[${index}]`, q);
  document.getElementsByClassName("val")[index].value = q;
  Total();
  UpdateItselt(index);
}

function Decrease(id, index) {
  // index--;
  let q = parseInt(localStorage.getItem(`qty[${index}]`));
  q = q - 1;
  localStorage.setItem(`qty[${index}]`, q);
  document.getElementsByClassName("val")[index].value = q;
  // q--;

  if (q <= 0) {
    localStorage.removeItem(`name[${index}]`);
    localStorage.removeItem(`price[${index}]`);
    localStorage.removeItem(`qty[${index}]`);
    localStorage.removeItem(`image[${index}]`);
    document
      .getElementsByClassName("cart-item")
      [index].classList.add("hideMeContent");
    document.getElementById("button-id" + id).disabled = false;
  } else UpdateItselt(index);

  Total();
}
function Total() {
  let total = 0;
  for (let i = 0; i <= ind; i++) {
    let q = parseInt(localStorage.getItem(`qty[${i}]`));
    let p = parseInt(localStorage.getItem(`price[${i}]`));

    if (q >= 1 ) total = total + p * q;
    
  }
  CheckEmpty();
  document.getElementsByClassName("trs")[0].innerHTML = total;
}
function UpdateItselt(ind) {
  let q = parseInt(localStorage.getItem(`qty[${ind}]`));
  let p = parseInt(localStorage.getItem(`price[${ind}]`));

  document.getElementsByClassName("rs")[ind].innerHTML = q * p;
}

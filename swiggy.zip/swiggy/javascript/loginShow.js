var topval = 0;
/* used to set when we scroll page then show any where */
window.addEventListener("scroll", function () {
  topval = window.pageYOffset;
});

function OpenLogin() {
  let main3 = document.getElementsByClassName("main-box3")[0];
  let main = document.getElementsByClassName("main-box")[0];
  main.style.top = topval + "px";
  // let container = document.getElementsByClassName("main-container")[0];

  main.classList.add("showData");
  main3.classList.remove("showData");
  document.getElementById("dk").style.overflowY = "hidden";
}

function CloseLogin() {
  let main = document.getElementsByClassName("main-box")[0];
  main.classList.remove("showData");
  document.getElementById("dk").style.overflowY = "visible";
}

function ShowSignup() {
  let main = document.getElementsByClassName("main-box")[0];
  let main3 = document.getElementsByClassName("main-box3")[0];
  main3.style.top = topval + "px";

  main.classList.remove("showData");
  main3.classList.add("showData");
  document.getElementById("dk").style.overflowY = "hidden";
}

function CloseSignup() {
  let main3 = document.getElementsByClassName("main-box3")[0];
  main3.classList.remove("showData");
  document.getElementById("dk").style.overflowY = "visible";
}

/* Used in filter1 class in home.php and header2.php */
function ShowFilter() {
  let filter = document.getElementsByClassName("filter1")[0];
  filter.style.top = topval + "px";
  filter.classList.add("showData");
  document.getElementById("dk").style.overflowY = "hidden";
}

function HideFilter() {
  let filter = document.getElementsByClassName("filter1")[0];
  filter.classList.remove("showData");
  document.getElementById("dk").style.overflowY = "visible";
}

/* Used in Search box */
function ShowSearchBox() {
  let search = document.getElementsByClassName("main-div")[0];
  search.style.top = topval + "px";
  search.classList.add("showData");
  document.getElementById("dk").style.overflowY = "hidden";
}
function HideSearchBox() {
  let search = document.getElementsByClassName("main-div")[0];
  search.classList.remove("showData");
  document.getElementById("dk").style.overflowY = "visible";
  // alert("hellow");
}

/* Hide and Show Location */
function ShowLocation() {
  let location = document.getElementsByClassName("location")[0];
  location.style.top = topval + "px";
  location.classList.add("showData");

  document.getElementById("dk").style.overflowY = "hidden";
}
function HideLocation() {
  let location = document.getElementsByClassName("location")[0];
  location.classList.remove("showData");

  document.getElementById("dk").style.overflowY = "visible";
}

/* Used in pay signin */
function ShowLoginPay() {
  let login = document.getElementsByClassName("pay-login")[0];
  let login1 = document.getElementsByClassName("pay-login1")[0];

  let btn1 = document.getElementsByClassName("btn")[0];
  let btn2 = document.getElementsByClassName("btn")[1];
  btn1.classList.add("hideButton");
  btn2.classList.add("hideButton");

  login.classList.add("showData");
  login1.classList.remove("showData");
}
function ShowSigninPay() {
  let login = document.getElementsByClassName("pay-login")[0];
  let login1 = document.getElementsByClassName("pay-login1")[0];

  let btn1 = document.getElementsByClassName("btn")[0];
  let btn2 = document.getElementsByClassName("btn")[1];
  btn1.classList.add("hideButton");
  btn2.classList.add("hideButton");

  login1.classList.add("showData");
  login.classList.remove("showData");
}

/* Used in header bottom */
var x = 0;

function nextImage() {
  if (x >= 3) x = 0;
  var img = document.getElementsByClassName("nextImg");
  for (let i = 0; i < img.length; i++) {
    console.log("i=" + i);
    if (i >= x && i <= x + 3) {
      img[i].style.display = "block";
      console.log(i);
    } else {
      img[i].style.display = "none";
    }
  }
  console.log("x= " + x);
  x++;
}
nextImage();
//
